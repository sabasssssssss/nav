function [x_mapa, y_mapa, theta] = Localizacion_S(opciones)
    % Función optimizada de localización para el robot de limpieza
    % Implementa un enfoque robusto para la localización del robot
    % combinando odometría con corrección basada en balizas y filtro de Kalman
    %
    % Parámetros:
    %   opciones - Estructura con parámetros configurables:
    %     - opciones.robot_name: Nombre del robot (por defecto: 'Limpiator')
    %     - opciones.usar_kalman: Usar filtro de Kalman (por defecto: true)
    %     - opciones.matriz_covarianza: Matriz de covarianza inicial (por defecto: diagonal con valores [0.1, 0.1, 0.05])
    %     - opciones.umbral_distancia: Distancia para detección de balizas (por defecto: 1.5)
    %     - opciones.factor_confianza: Factor de confianza en las balizas (por defecto: 0.7)
    %     - opciones.usar_sensores: Usar sensores para mejorar localización (por defecto: true)
    %     - opciones.cargar_balizas_xml: Cargar balizas desde archivo XML (por defecto: false)
    %     - opciones.archivo_xml: Ruta al archivo XML con balizas (por defecto: 'restaurant.xml')
    
    % Configuración de opciones por defecto
    if nargin < 1
        opciones = struct();
    end
    
    % Parámetros configurables con valores por defecto
    robot_name = getfield_with_default(opciones, 'robot_name', 'Limpiator');
    usar_kalman = getfield_with_default(opciones, 'usar_kalman', true);
    umbral_distancia = getfield_with_default(opciones, 'umbral_distancia', 1.5);
    factor_confianza = getfield_with_default(opciones, 'factor_confianza', 0.7);
    usar_sensores = getfield_with_default(opciones, 'usar_sensores', true);
    cargar_balizas_xml = getfield_with_default(opciones, 'cargar_balizas_xml', false);
    archivo_xml = getfield_with_default(opciones, 'archivo_xml', 'restaurant.xml');
    debug = getfield_with_default(opciones, 'debug', false);
    world = getfield_with_default(opciones, 'world', 'world1');
    
    % Inicializar matriz de covarianza si no se proporciona
    if ~isfield(opciones, 'matriz_covarianza') || isempty(opciones.matriz_covarianza)
        matriz_covarianza = diag([0.1, 0.1, 0.05]);  % Valores por defecto para [x, y, theta]
    else
        matriz_covarianza = opciones.matriz_covarianza;
    end
    
    % Cargar factores de calibración si existen
    try
        datos_calibracion = load('calibracion_robot.mat');
        factor_dist = datos_calibracion.calibracion.factor_distancia;
        factor_ang = datos_calibracion.calibracion.factor_angulo;
        if debug
            disp(['ℹ️ Factores de calibración cargados: Distancia=', num2str(factor_dist), ', Ángulo=', num2str(factor_ang)]);
        end
    catch ME
        factor_dist = 1.0;
        factor_ang = 1.0;
        if debug
            disp(['⚠️ No se encontraron factores de calibración (', ME.message, '), usando valores por defecto']);
        end
    end
    
    % 📌 Definición de balizas con coordenadas conocidas
    balizas = [];
    if cargar_balizas_xml && exist(archivo_xml, 'file')
        try
            [~, balizas_cargadas] = parse_xml_map_S(archivo_xml);
            if ~isempty(balizas_cargadas)
                balizas = balizas_cargadas;
                if debug
                    disp(['✅ Balizas cargadas desde XML: ', num2str(size(balizas, 1)), ' balizas encontradas']);
                    disp('Posiciones de balizas:');
                    disp(balizas);
                end
            else
                disp('❌ No se encontraron balizas en el XML. Abortando localización.');
                x_mapa = NaN; y_mapa = NaN; theta = NaN;
                return;
            end
        catch ME
            disp(['❌ Error al cargar balizas desde XML (', ME.message, '). Abortando localización.']);
            x_mapa = NaN; y_mapa = NaN; theta = NaN;
            return;
        end
    else
        % Usar balizas predefinidas si no se carga desde XML o el archivo no existe
        balizas = definir_balizas_predefinidas();
    end
    
    % 📌 Obtener la ubicación del robot en Apolo
    try
        pos_apolo = apoloGetLocationMRobot(robot_name, world); % Requiere Apolo
        x_apolo = pos_apolo(1);
        y_apolo = pos_apolo(2);
        theta = pos_apolo(3);
    catch ME
        if debug
            disp(['⚠️ Error al obtener posición de Apolo (apoloGetLocationMRobot): ', ME.message]);
        end
        % Valores por defecto si Apolo no está disponible o hay error
        x_apolo = 0;
        y_apolo = 0;
        theta = 0;
    end
    
    % 📌 Convertir de Apolo a Mapa Binario (asumiendo un offset y una inversión en Y)
    % Estas conversiones deben ser consistentes con crear_mapa_ocupacion_S
    % Las coordenadas del mapa binario se asumen de 0 a 34 para un mapa de 35x35
    % y_mapa = 34 - y_apolo; es para invertir el eje Y si Apolo tiene el origen abajo y MATLAB arriba
    % Si Apolo tiene el origen en el centro y el mapa binario en la esquina, se necesita un ajuste.
    % Basado en el archivo restaurant.xml, las coordenadas son positivas, así que asumimos un origen en (0,0)
    % y un mapeo directo a celdas. Si el mapa es de 35x35, las celdas van de 1 a 35.
    % Si las coordenadas de Apolo son en metros y el mapa en celdas, se necesita una resolución.
    % Por ahora, se mantiene la conversión original asumiendo que Apolo usa un sistema similar al mapa binario.
    x_mapa = x_apolo + 1;         
    y_mapa = 34 - y_apolo;        
    
    % Obtener datos de sensores si se solicita
    datos_sensores = struct();
    if usar_sensores
        try
            % Añadir el parámetro 'world' explícitamente
            datos_sensores.uc0 = apoloGetUltrasonicSensor('uc0', world); % Requiere Apolo
            datos_sensores.ul1 = apoloGetUltrasonicSensor('ul1', world); % Requiere Apolo
            datos_sensores.ur1 = apoloGetUltrasonicSensor('ur1', world); % Requiere Apolo
            try
                datos_sensores.laser = apoloGetLaserData('LMS100', world); % Requiere Apolo
            catch ME_laser
                if debug
                    disp(['⚠️ No se pudieron obtener datos de láser (', ME_laser.message, ')']);
                end
            end
            if debug
                disp('✅ Datos de sensores obtenidos correctamente');
            end
        catch ME_sensor
            if debug
                disp(['⚠️ Error al obtener datos de sensores (', ME_sensor.message, ')']);
            end
        end
    end
    
    % Obtener odometría como medida de predicción
    try
        % Añadir el parámetro 'world' explícitamente
        odometria = apoloGetOdometry(robot_name, world); % Requiere Apolo
        x_odo = odometria(1) + 1;
        y_odo = 34 - odometria(2);
        theta_odo = odometria(3);
    catch ME
        if debug
            disp(['⚠️ Error al obtener odometría de Apolo (apoloGetOdometry): ', ME.message]);
        end
        % Valores por defecto si Apolo no está disponible o hay error
        x_odo = x_mapa;
        y_odo = y_mapa;
        theta_odo = theta;
    end
    
    % Aplicar factores de calibración a la odometría
    delta_x = (x_odo - x_mapa) * factor_dist;
    delta_y = (y_odo - y_mapa) * factor_dist;
    delta_theta = (theta_odo - theta) * factor_ang;
    
    % Normalizar ángulo
    delta_theta = normalizar_angulo(delta_theta);
    
    % Si se solicita usar Kalman
    if usar_kalman
        % Vector de estado actual [x, y, theta]
        estado_actual = [x_mapa; y_mapa; theta];
        
        % Predicción basada en odometría calibrada
        estado_predicho = estado_actual + [delta_x; delta_y; delta_theta];
        
        % Matriz de transición de estado (modelo de movimiento)
        F = eye(3);  % Matriz identidad para modelo lineal simple
        
        % Matriz de covarianza de proceso (incertidumbre del movimiento)
        % Aumenta con la distancia recorrida y el ángulo girado
        dist_recorrida = sqrt(delta_x^2 + delta_y^2);
        Q = diag([
            max(0.01, dist_recorrida * 0.1),  % Incertidumbre en X
            max(0.01, dist_recorrida * 0.1),  % Incertidumbre en Y
            max(0.005, abs(delta_theta) * 0.2)  % Incertidumbre en theta
        ]);
        
        % Actualizar matriz de covarianza (predicción)
        matriz_covarianza_pred = F * matriz_covarianza * F' + Q;
        
        % Varianza de la distancia y el ángulo de las balizas (ejemplo del trabajo de referencia)
        var_dist = 1.9e-4;
        var_ang = 3.8e-4;

        % Llamar a la función modularizada del filtro de Kalman
        opciones.datos_sensores = datos_sensores; % Pasar datos de sensores a la función de Kalman
        [estado_corregido, matriz_covarianza] = kalman_filter_update_S(estado_predicho, matriz_covarianza_pred, balizas, umbral_distancia, var_dist, var_ang, opciones);
            
        % Extraer valores corregidos
        x_mapa = estado_corregido(1);
        y_mapa = estado_corregido(2);
        theta = estado_corregido(3);
        
        % Guardar matriz de covarianza actualizada para uso futuro
        opciones.matriz_covarianza = matriz_covarianza;
        
    else
        % Método original mejorado (sin Kalman completo)
        % Predicción basada en odometría calibrada
        x_pred = x_mapa + delta_x;
        y_pred = y_mapa + delta_y;
        theta_pred = theta + delta_theta;
        
        % Buscar balizas cercanas para corrección
        baliza_detectada = false;
        for i = 1:size(balizas, 1)
            % Calcular distancia a la baliza
            dist_baliza = norm([balizas(i,1) - x_pred, balizas(i,2) - y_pred]);
            
            if dist_baliza < umbral_distancia
                baliza_detectada = true;
                
                % Corrección basada en la baliza con factor de confianza
                x_mapa = x_pred * (1-factor_confianza) + balizas(i,1) * factor_confianza;
                y_mapa = y_pred * (1-factor_confianza) + balizas(i,2) * factor_confianza;
                
                % Mantener theta de la predicción
                theta = theta_pred;
                
                % Mostrar información de depuración
                if debug
                    disp(['📡 Baliza ', num2str(i), ' detectada en (', num2str(balizas(i,1)), ',', num2str(balizas(i,2)), ') - Corrigiendo posición']);
                end
                
                break;
            end
        end
        
        % Si no se detectó ninguna baliza, usar la predicción
        if ~baliza_detectada
            x_mapa = x_pred;
            y_mapa = y_pred;
            theta = theta_pred;
        end
    end
    
    % Normalizar ángulo final
    theta = normalizar_angulo(theta);
    
    % 📌 Mostrar la conversión en la consola (solo si se solicita depuración)
    if debug
        disp(['📍 Posición en Apolo: X=', num2str(x_apolo), ', Y=', num2str(y_apolo), ', Theta=', num2str(theta)]);
        disp(['📍 Posición en el mapa binario: X=', num2str(x_mapa), ', Y=', num2str(y_mapa)]);
        
        if usar_kalman
            % Mostrar información de incertidumbre
            incertidumbre_x = sqrt(matriz_covarianza(1,1));
            incertidumbre_y = sqrt(matriz_covarianza(2,2));
            incertidumbre_theta = sqrt(matriz_covarianza(3,3));
            
            disp(['📊 Incertidumbre: X=±', num2str(incertidumbre_x), ', Y=±', num2str(incertidumbre_y), ', Theta=±', num2str(incertidumbre_theta)]);
        end
    end
end

% Función para normalizar ángulos al rango [-pi, pi]
function angulo = normalizar_angulo(angulo)
    while angulo > pi
        angulo = angulo - 2*pi;
    end
    while angulo < -pi
        angulo = angulo + 2*pi;
    end
end

% Función para definir balizas predefinidas
function balizas = definir_balizas_predefinidas()
    % Ampliado de 3 a 15 balizas para mejor cobertura del entorno
    balizas = [
        1, 11;   % Baliza 1
        8, 3;    % Baliza 2
        7, 28;   % Baliza 3
        15, 15;  % Baliza 4
        20, 5;   % Baliza 5
        25, 20;  % Baliza 6
        30, 10;  % Baliza 7
        12, 25;  % Baliza 8
        18, 30;  % Baliza 9
        5, 20;   % Baliza 10
        3, 3;    % Baliza 11
        28, 28;  % Baliza 12
        10, 20;  % Baliza 13
        22, 15;  % Baliza 14
        15, 5    % Baliza 15
    ];
end

% Función auxiliar para obtener campos de estructura con valores por defecto
function valor = getfield_with_default(estructura, campo, valor_default)
    if isfield(estructura, campo)
        valor = estructura.(campo);
    else
        valor = valor_default;
    end
end



