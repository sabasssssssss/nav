function mapa = crear_mapa_ocupacion_S(opciones)
    % Función para crear un mapa de ocupación binario basado en los archivos XML proporcionados.
    % Asegura que solo se utilicen los mapas de calibración y restaurante.
    %
    % Parámetros:
    %   opciones - Estructura con parámetros configurables:
    %     - opciones.xml_path: Ruta al archivo XML del mapa (e.g., 'restaurant.xml' o 'calibracion.xml').
    %     - opciones.resolucion: Resolución del mapa (celdas/metro) (por defecto: 10).
    %     - opciones.archivo_salida: Nombre del archivo para guardar el mapa (por defecto: 'mapa_ocupacion.mat').
    %     - opciones.visualizar: Mostrar el mapa creado (por defecto: true).
    
    % Configuración de opciones por defecto
    if nargin < 1
        opciones = struct();
    end
    
    % Parámetros configurables con valores por defecto
    resolucion = getfield_with_default(opciones, 'resolucion', 10);
    archivo_salida = getfield_with_default(opciones, 'archivo_salida', 'mapa_ocupacion.mat');
    visualizar = getfield_with_default(opciones, 'visualizar', true);
    xml_path = getfield_with_default(opciones, 'xml_path', 'root1.xml'); % Por defecto, usar root1.xml
    debug = getfield_with_default(opciones, 'debug', false);

    % Inicializar tamaño del mapa
    tamano = [0, 0]; % Se determinará dinámicamente a partir del XML

    % Parsear el archivo XML para obtener los vértices de los obstáculos y balizas
    vertices_obstaculos = [];
    balizas_xml = [];
    try
        [vertices_obstaculos, balizas_xml] = parse_xml_map_S(xml_path);
        if debug
            disp(['✅ XML ' xml_path ' parseado correctamente.']);
        end
        
        % Determinar el tamaño del mapa a partir de los vértices del XML
        if ~isempty(vertices_obstaculos)
            % Encontrar los límites min/max para determinar el tamaño del mapa
            min_x = min(vertices_obstaculos(:,1));
            max_x = max(vertices_obstaculos(:,1));
            min_y = min(vertices_obstaculos(:,2));
            max_y = max(vertices_obstaculos(:,2));
            
            % Calcular el tamaño del mapa en celdas, añadiendo un margen para asegurar que todo quepa
            % y ajustando para que el origen (0,0) esté en la esquina inferior izquierda del mapa lógico
            % Asumimos que las coordenadas del XML pueden ser negativas.
            
            % Offset para mover las coordenadas al primer cuadrante si hay negativos
            offset_x = 0;
            offset_y = 0;
            if min_x < 0
                offset_x = abs(min_x);
            end
            if min_y < 0
                offset_y = abs(min_y);
            end
            
            % Tamaño del mapa en unidades del mundo real
            ancho_mundo = max_x + offset_x;
            alto_mundo = max_y + offset_y;
            
            % Tamaño del mapa en celdas (redondeado hacia arriba)
            tamano = [ceil(ancho_mundo * resolucion), ceil(alto_mundo * resolucion)];
            
            if debug
                disp(['ℹ️ Tamaño del mapa determinado a partir del XML: [' num2str(tamano(1)) ', ' num2str(tamano(2)) ']']);
                disp(['ℹ️ Offset aplicado: X=' num2str(offset_x) ', Y=' num2str(offset_y)]);
            end
        else
            if debug
                disp('⚠️ No se encontraron vértices de obstáculos en el XML para determinar el tamaño del mapa.');
            end
        end
    catch e
        disp(['❌ Error al parsear el XML ' xml_path ': ' e.message]);
    end

    % Si el tamaño del mapa sigue siendo 0,0 (ej. XML vacío o error), establecer un tamaño por defecto
    if tamano(1) == 0 || tamano(2) == 0
        tamano = [35, 35]; % Tamaño por defecto si no se pudo determinar
        if debug
            disp(['⚠️ No se pudo determinar el tamaño del mapa, usando tamaño por defecto: [' num2str(tamano(1)) ', ' num2str(tamano(2)) ']']);
        end
    end

    % Crear mapa de ocupación como una matriz lógica
    % Inicialmente todo libre (true = libre, false = ocupado)
    mapa_logico = true(tamano(2), tamano(1)); 
    
    % Establecer obstáculos desde el XML
    if ~isempty(vertices_obstaculos)
        % Offset para ajustar las coordenadas del XML al sistema de coordenadas de la matriz lógica
        % donde (1,1) es la esquina inferior izquierda.
        offset_x_mapa = 0;
        offset_y_mapa = 0;
        if min(vertices_obstaculos(:,1)) < 0
            offset_x_mapa = abs(min(vertices_obstaculos(:,1)));
        end
        if min(vertices_obstaculos(:,2)) < 0
            offset_y_mapa = abs(min(vertices_obstaculos(:,2)));
        end

        for k = 1:size(vertices_obstaculos, 1)
            % Convertir coordenadas del mundo real a índices de celda
            x_coord_world = vertices_obstaculos(k, 1);
            y_coord_world = vertices_obstaculos(k, 2);
            
            % Aplicar offset y resolución para obtener coordenadas de celda
            x_celda = round((x_coord_world + offset_x_mapa) * resolucion) + 1;
            y_celda = round((y_coord_world + offset_y_mapa) * resolucion) + 1;
            
            % Asegurarse de que las coordenadas estén dentro de los límites del mapa
            if x_celda >= 1 && x_celda <= tamano(1) && y_celda >= 1 && y_celda <= tamano(2)
                % Marcar como ocupado (false)
                % Recordar que MATLAB indexa (fila, columna) y la Y del mapa es la fila (invertida)
                mapa_logico(tamano(2) - y_celda + 1, x_celda) = false; 
            end
        end
        if debug
            disp('✅ Obstáculos del XML añadidos al mapa lógico.');
        end
    end
    
    % Marcar posiciones de balizas (como pequeños puntos libres si están en un obstáculo)
    if ~isempty(balizas_xml)
        for i = 1:size(balizas_xml, 1)
            x_baliza_world = balizas_xml(i,1);
            y_baliza_world = balizas_xml(i,2);
            
            % Convertir coordenadas del mundo real a índices de celda
            x_baliza_celda = round((x_baliza_world + offset_x_mapa) * resolucion) + 1;
            y_baliza_celda = round((y_baliza_world + offset_y_mapa) * resolucion) + 1;

            % Asegurar que las balizas estén dentro de los límites del mapa
            if x_baliza_celda >= 1 && x_baliza_celda <= tamano(1) && y_baliza_celda >= 1 && y_baliza_celda <= tamano(2)
                % Asegurar que la celda de la baliza esté libre
                mapa_logico(tamano(2) - y_baliza_celda + 1, x_baliza_celda) = true;  % true = libre
            end
        end
        if debug
            disp('✅ Balizas del XML añadidas al mapa lógico.');
        end
    end
    
    % Devolver la matriz lógica directamente
    mapa = mapa_logico; 

    % Guardar el mapa en formato .mat
    save(archivo_salida, 'mapa');
    if debug
        disp(['✅ Mapa guardado como ' archivo_salida]);
    end
    
    % Visualizar el mapa si se solicita
    if visualizar
        figure;
        imshow(~mapa, 'InitialMagnification', 'fit'); % Invertir para que los obstáculos sean negros
        title(['Mapa de Ocupación (' xml_path ')']);
        colormap(gray); % Para que los obstáculos sean negros y el espacio libre blanco
        axis on;
        grid on;
        xlabel('X (celdas)');
        ylabel('Y (celdas)');
    end
end

% Función auxiliar para obtener campos de estructura con valores por defecto
function valor = getfield_with_default(estructura, campo, valor_default)
    if isfield(estructura, campo)
        valor = estructura.(campo);
    else
        valor = valor_default;
    end
end


