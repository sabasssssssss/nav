function navegador_principal_S()
    % Función principal optimizada que integra todos los componentes del sistema de navegación
    % Coordina la calibración, localización, planificación y ejecución de movimientos
    
    disp("=== Iniciando Sistema de Navegación Avanzado ===");
    
    % Configuración general
    opciones = struct();
    opciones.robot_name = 'Limpiator';
    opciones.debug = true;
    opciones.usar_kalman = true;
    opciones.visualizar = true;
    opciones.cargar_balizas_xml = true; % Asegurarse de que las balizas se carguen desde XML
    opciones.archivo_xml = 'root1.xml'; % Usar root1.xml por defecto
    opciones.world = 'world1';
    
    try
        % Paso 1: Cargar o crear mapa de ocupación
        disp("🔄 Paso 1: Cargando o creando mapa de ocupación...");
        % crear_mapa_ocupacion_S ahora devuelve una matriz lógica
        mapa = crear_mapa_ocupacion_S(struct("visualizar", opciones.visualizar, "xml_path", opciones.archivo_xml));
        
        % Paso 2: Calibración inicial
        disp("🔄 Paso 2: Realizando calibración inicial...");
        try
            % Usar calibracion.xml para la calibración
            calibracion_inicial_S(struct("num_iteraciones", 3, "usar_balizas", true, "debug", opciones.debug, "xml_calibracion_path", "EntornoBasico.xml"));
            if exist('calibracion_robot.mat', 'file')
                load('calibracion_robot.mat');
                disp(['ℹ️ Factores de calibración: Distancia=', num2str(calibracion.factor_distancia), ', Ángulo=', num2str(calibracion.factor_angulo)]);
            end
        catch ME
            disp(['⚠️ Error en calibración inicial: ', ME.message, '. Continuando sin calibración.']);
        end
        
        % Paso 3: Localización inicial
        disp("🔄 Paso 3: Obteniendo localización inicial...");
        % Asegurarse de que Localizacion_S use el archivo XML correcto para las balizas
        opciones.archivo_xml = 'root1.xml'; % Para la localización, usar el mapa root1
        [x, y, theta] = Localizacion_S(opciones);
        disp(['📍 Posición inicial: (', num2str(x), ',', num2str(y), ',', num2str(theta), ')']);
        
        % Paso 4: Planificar exploración
        disp("🔄 Paso 4: Planificando exploración...");
        % mensajero_exploracion_S espera un objeto binaryOccupancyMap o una matriz lógica
        ruta_exploracion = mensajero_exploracion_S(mapa, [x, y], struct('max_puntos', 15, 'visualizar', opciones.visualizar, 'debug', opciones.debug));
        
        % Paso 5: Verificar obstáculos en la ruta
        disp("🔄 Paso 5: Verificando obstáculos en la ruta...");
        ruta_final = obstaculos_S(mapa, ruta_exploracion, struct('actualizar_mapa', true, 'visualizar', opciones.visualizar, 'debug', opciones.debug));
        
        % Visualizar ruta final si se solicita
        if opciones.visualizar
            figure;
            hold on;
            imshow(~mapa, 'InitialMagnification', 'fit'); % Mostrar la matriz lógica
            colormap(gray);
            plot(ruta_exploracion(:,1), ruta_exploracion(:,2), 'r-o', 'LineWidth', 1, 'DisplayName', 'Ruta Exploración');
            plot(ruta_final(:,1), ruta_final(:,2), 'g-*', 'LineWidth', 2, 'DisplayName', 'Ruta Final');
            scatter(x, y, 100, 'b', 'filled', 'DisplayName', 'Posición Inicial');
            legend('show');
            title('Plan de Navegación');
            hold off;
        end
        
        % Paso 6: Ejecutar movimientos
        disp("🔄 Paso 6: Ejecutando movimientos...");
        
        % Inicializar variables para seguimiento
        posiciones = [x, y, theta];
        errores_odometria = [];
        
        % Limitar a un número razonable de puntos para prueba
        num_puntos = min(size(ruta_final, 1), 5); % Limitar a 5 puntos para una prueba rápida
        
        for i = 1:num_puntos
            % Comprobación para evitar error de índice si la ruta se acorta
            if i > size(ruta_final, 1)
                if opciones.debug
                    disp(['⚠️ La ruta se ha acortado durante la ejecución. Finalizando bucle en i = ', num2str(i), ' de ', num2str(num_puntos)]);
                end
                break;
            end
            
            disp(['🚶 Moviendo a punto ', num2str(i),'/',num2str(num_puntos),': (', num2str(ruta_final(i,1)), ',', num2str(ruta_final(i,2)), ')']);
            
            % Obtener posición actual
            [x_actual, y_actual, theta_actual] = Localizacion_S(opciones);
            
            % Mover el robot en Apolo a la posición estimada por el algoritmo
            % Esto simula el teletransporte para mantener la visualización sincronizada
            try
                apoloSetRobotPose_S(opciones.robot_name, x_actual, y_actual, theta_actual, opciones.world);
                apoloUpdate(opciones.world);
                pause(0.1); % Pequeña pausa para la visualización
            catch ME
                if opciones.debug
                    disp(['⚠️ Error al interactuar con Apolo (apoloSetRobotPose_S): ', ME.message]);
                end
            end

            % Calcular vector hacia el objetivo
            dx = ruta_final(i,1) - x_actual;
            dy = ruta_final(i,2) - y_actual;
            distancia = sqrt(dx^2 + dy^2);
            angulo_objetivo = atan2(dy, dx);
            
            % Calcular diferencia angular
            diff_angulo = angulo_objetivo - theta_actual;
            diff_angulo = normalizar_angulo(diff_angulo);
            
            % Girar hacia el objetivo
            disp(['🔄 Girando ', num2str(diff_angulo*180/pi), ' grados']);
            try
                apoloMoveMRobot(opciones.robot_name, [0, diff_angulo], 1.0, opciones.world);
                apoloUpdate(opciones.world);
                pause(0.5);
            catch ME
                if opciones.debug
                    disp(['⚠️ Error al interactuar con Apolo (apoloMoveMRobot - giro): ', ME.message]);
                end
            end
            
            % Avanzar hacia el objetivo
            disp(['🚶 Avanzando ', num2str(distancia), ' metros']);
            try
                apoloMoveMRobot(opciones.robot_name, [distancia, 0], distancia, opciones.world);
                apoloUpdate(opciones.world);
                pause(0.5);
            catch ME
                if opciones.debug
                    disp(['⚠️ Error al interactuar con Apolo (apoloMoveMRobot - avance): ', ME.message]);
                end
            end
            
            % Obtener posición después del movimiento
            [x_despues, y_despues, theta_despues] = Localizacion_S(opciones);
            
            % Calcular error de odometría (distancia entre el punto objetivo y la posición real)
            error_dist = sqrt((ruta_final(i,1) - x_despues)^2 + (ruta_final(i,2) - y_despues)^2);
            errores_odometria = [errores_odometria; error_dist];
            
            % Registrar posición
            posiciones = [posiciones; x_despues, y_despues, theta_despues];
            
            % Corregir odometría si es necesario
            if error_dist > 0.5
                disp(['⚠️ Error de posición significativo: ', num2str(error_dist), ' metros. Corrigiendo odometría...']);
                correccion_balizas_S(opciones); % Ahora es una función interna
            end
            
            % Actualizar mapa si se detectan obstáculos (simplificado)
            try
                % Intentar obtener datos de sensores ultrasónicos
                uc0 = apoloGetUltrasonicSensor('uc0', opciones.world);
                ul1 = apoloGetUltrasonicSensor('ul1', opciones.world);
                ur1 = apoloGetUltrasonicSensor('ur1', opciones.world);
                
                % Si hay obstáculo cercano, actualizar mapa
                if min([uc0, ul1, ur1]) < 0.5
                    disp('⚠️ Obstáculo cercano detectado, actualizando mapa...');
                    
                    % Estimar posición del obstáculo basado en la orientación del robot y la distancia del sensor
                    % (Esta es una estimación muy básica, para un sistema real se necesitaría un mapeo más robusto)
                    angulo_robot = theta_despues; % Orientación actual del robot
                    dist_min_sensor = min([uc0, ul1, ur1]);
                    
                    % Coordenadas del obstáculo en el sistema de coordenadas del mapa
                    x_obstaculo_mapa = x_despues + dist_min_sensor * cos(angulo_robot);
                    y_obstaculo_mapa = y_despues + dist_min_sensor * sin(angulo_robot);
                    
                    % Marcar obstáculo en el mapa lógico (false = ocupado)
                    % Asegurarse de que las coordenadas estén dentro de los límites del mapa
                    mapa_filas = size(mapa, 1);
                    mapa_cols = size(mapa, 2);
                    
                    x_idx = round(x_obstaculo_mapa); % Convertir a índice de columna
                    y_idx = round(mapa_filas - y_obstaculo_mapa + 1); % Convertir a índice de fila (invertido)

                    if x_idx >= 1 && x_idx <= mapa_cols && y_idx >= 1 && y_idx <= mapa_filas
                        mapa(y_idx, x_idx) = false; % Marcar como ocupado
                        disp(['✅ Obstáculo marcado en el mapa en (', num2str(x_obstaculo_mapa), ',', num2str(y_obstaculo_mapa), ')']);
                    else
                        disp('⚠️ Obstáculo detectado fuera de los límites del mapa.');
                    end
                    
                    % Recalcular ruta si es necesario
                    if i < num_puntos
                        disp('🔄 Recalculando ruta debido a obstáculo...');
                        ruta_restante = obstaculos_S(mapa, ruta_final(i:end,:), struct('actualizar_mapa', true, 'visualizar', opciones.visualizar, 'debug', opciones.debug));
                        ruta_final = [ruta_final(1:i-1,:); ruta_restante];
                        num_puntos = min(size(ruta_final, 1), num_puntos); % Actualizar num_puntos si la ruta se acorta
                        if i > size(ruta_final, 1)
                            if opciones.debug
                                disp(['⚠️ Tras recalcular la ruta, el índice actual i = ', num2str(i), ' supera el tamaño de la nueva ruta (', num2str(size(ruta_final, 1)), '). Finalizando bucle.']);
                            end
                            break;
                        end
                    end
                end
            catch ME_sensor_update
                if opciones.debug
                    disp(['⚠️ Error al actualizar mapa por sensores (apoloGetUltrasonicSensor): ', ME_sensor_update.message]);
                end
            end
        end
        
        % Paso 7: Análisis de resultados
        disp("🔄 Paso 7: Analizando resultados...");
        
        % Calcular estadísticas de error
        if ~isempty(errores_odometria)
            error_medio = mean(errores_odometria);
            error_max = max(errores_odometria);
            disp(['📊 Error medio de posición: ', num2str(error_medio), ' metros']);
            disp(['📊 Error máximo de posición: ', num2str(error_max), ' metros']);
        else
            disp('📊 No se registraron errores de odometría para analizar.');
            error_medio = 0;
            error_max = 0;
        end
        
        % Visualizar trayectoria si se solicita
        if opciones.visualizar && size(posiciones, 1) > 1
            figure;
            hold on;
            imshow(~mapa, 'InitialMagnification', 'fit'); % Mostrar la matriz lógica
            colormap(gray);
            plot(posiciones(:,1), posiciones(:,2), 'b-o', 'LineWidth', 2, 'DisplayName', 'Trayectoria Real');
            plot(ruta_final(1:num_puntos,1), ruta_final(1:num_puntos,2), 'g--*', 'LineWidth', 1, 'DisplayName', 'Ruta Planificada');
            legend('show');
            title('Trayectoria de Navegación');
            hold off;
        end
        
        % Guardar resultados
        resultados = struct();
        resultados.posiciones = posiciones;
        resultados.errores_odometria = errores_odometria;
        resultados.error_medio = error_medio;
        resultados.error_max = error_max;
        resultados.fecha = datestr(now);
        
        save('resultados_navegacion.mat', 'resultados');
        disp('✅ Resultados guardados en resultados_navegacion.mat');
        
        % Paso 8: Mostrar resultados finales
        disp("🔄 Paso 8: Obteniendo localización final...");
        [x_final, y_final, theta_final] = Localizacion_S(opciones);
        disp(['📍 Posición final: (', num2str(x_final), ',', num2str(y_final), ',', num2str(theta_final), ')']);
        
        disp("=== Sistema de Navegación completado con éxito ===");
        
    catch e
        % Manejo de errores
        disp(['❌ Error en el sistema de navegación: ', e.message]);
        disp('⚠️ Deteniendo ejecución y guardando estado actual...');
        % Mostrar stack del error
        for k = 1:length(e.stack)
            disp(['En ', e.stack(k).file, ' (línea ', num2str(e.stack(k).line), ')']);
        end
        % Intentar guardar estado actual
        try
            estado_error = struct();
            estado_error.mensaje = e.message;
            estado_error.stack = e.stack;
            estado_error.fecha = datestr(now);
            save('estado_error_navegacion.mat', 'estado_error');
            disp('✅ Estado de error guardado en estado_error_navegacion.mat');
        catch
            disp('❌ No se pudo guardar el estado de error');
        end
    end
end

% Función para normalizar ángulos al rango [-pi, pi]
function angulo = normalizar_angulo(angulo)
    while angulo > pi
        angulo = angulo - 2*pi;
    end
    while angulo < -pi
        angulo = angulo + 2*pi;
    end
end


